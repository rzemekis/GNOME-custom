#!/bin/bash
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Apply wallpaper
cp "$SCRIPT_DIR/wallpaper.jpg" ~/.config/background
echo "✅ Обои установлены"

# Install extensions
mkdir -p ~/.local/share/gnome-shell/extensions
for ext in blur-my-shell@aunetx dash-to-dock@micxgx.gmail.com touchpad-gesture-customization@coooolapps.com; do
  if [ -d "$SCRIPT_DIR/$ext" ]; then
    cp -r "$SCRIPT_DIR/$ext" ~/.local/share/gnome-shell/extensions/
    echo "✅ Расширение: $ext"
  fi
done

# Extensions not bundled - need manual install
echo ""
echo "⚠️  Установи вручную (нет в архиве):"
echo "   - dash-to-panel@jderose9.github.com"
echo "   - gestureImprovements@gestures"
echo ""

# Load dconf settings
dconf load / < "$SCRIPT_DIR/gnome-settings.dconf"
echo "✅ Настройки GNOME применены"
echo ""
echo "🔄 Перезапусти GNOME Shell (Alt+F2 → r → Enter) или перелогинься"
