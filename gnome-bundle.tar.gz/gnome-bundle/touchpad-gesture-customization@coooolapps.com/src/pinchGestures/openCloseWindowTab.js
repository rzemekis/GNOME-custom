import Clutter from 'gi://Clutter';
import Shell from 'gi://Shell';
import St from 'gi://St';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as Util from 'resource:///org/gnome/shell/misc/util.js';
import { PinchGestureType } from '../../common/settings.js';
import { WIDGET_SHOWING_DURATION } from '../../constants.js';
import { TouchpadPinchGesture } from './pinchTracker.js';
import { easeActor } from '../utils/environment.js';
import { getVirtualKeyboard } from '../utils/keyboard.js';

const END_OPACITY = 0;
const PINCH_THRESHOLD = 0.02;
var OpenCloseWindowTabGestureState;

(function (OpenCloseWindowTabGestureState) {
    OpenCloseWindowTabGestureState[OpenCloseWindowTabGestureState["PINCH_IN"] = -1] = "PINCH_IN";
    OpenCloseWindowTabGestureState[OpenCloseWindowTabGestureState["DEFAULT"] = 0] = "DEFAULT";
    OpenCloseWindowTabGestureState[OpenCloseWindowTabGestureState["PINCH_OUT"] = 1] = "PINCH_OUT";
})(OpenCloseWindowTabGestureState || (OpenCloseWindowTabGestureState = {}));

const PINCH_IN_ANIMATION = {
    style: 'gie-close-window-preview',
    start: 1,
    end: 0.5,
};
const PINCH_OUT_ANIMATION = {
    style: 'gie-open-window-preview',
    start: 0.5,
    end: 1,
};
export class OpenCloseWindowTabExtension {

    constructor(nfingers, actionType) {
        this._activePinchAnimation = null;
        this._actionType = actionType;
        this._keyboard = getVirtualKeyboard();
        this._preview = new St.Widget({
            reactive: false,
            style_class: 'gie-close-window-preview',
            visible: false,
        });
        this._preview.set_pivot_point(0.5, 0.5);
        Main.layoutManager.uiGroup.add_child(this._preview);
        this._pinchTracker = new TouchpadPinchGesture({
            nfingers: nfingers,
            allowedModes: Shell.ActionMode.NORMAL,
            pinchSpeed: 0.25,
        });
        this._pinchTracker.connect('begin', this.gestureBegin.bind(this));
        this._pinchTracker.connect('update', this.gestureUpdate.bind(this));
        this._pinchTracker.connect('end', this.gestureEnd.bind(this));
    }

    destroy() {
        this._pinchTracker.destroy();
        this._preview.destroy();
    }

    gestureBegin(tracker) {
        this._activePinchAnimation = null;

        // if we are currently in middle of animations, ignore this event
        if (this._focusWindow)
            return;
        this._focusWindow =
            global.display.get_focus_window();
        if (!this._focusWindow)
            return;
        tracker.confirmPinch(0, [
            OpenCloseWindowTabGestureState.PINCH_IN,
            OpenCloseWindowTabGestureState.DEFAULT,
            OpenCloseWindowTabGestureState.PINCH_OUT,
        ], OpenCloseWindowTabGestureState.DEFAULT);
        const frame = this._focusWindow.get_frame_rect();
        this._preview.set_position(frame.x, frame.y);
        this._preview.set_size(frame.width, frame.height);
    }

    gestureUpdate(_tracker, progress) {
        progress = OpenCloseWindowTabGestureState.DEFAULT - progress;
        let startAnimation = false;

        if (this._activePinchAnimation == null) {
            if (Math.abs(progress) > PINCH_THRESHOLD) {
                this._activePinchAnimation =
                    progress > 0 ? PINCH_IN_ANIMATION : PINCH_OUT_ANIMATION;
                this._preview.set_style_class_name(this._activePinchAnimation.style);
                startAnimation = true;
            }
            else {
                return;
            }
        }

        if (this._activePinchAnimation == PINCH_OUT_ANIMATION) {
            progress = -progress;
        }

        const scale = Util.lerp(this._activePinchAnimation.start, this._activePinchAnimation.end, progress);
        this._preview.set_scale(scale, scale);
        this._preview.opacity = Util.lerp(255, END_OPACITY, progress);

        if (startAnimation) {
            // animate showing widget
            this._preview.show();
            easeActor(this._preview, {
                opacity: 255,
                mode: Clutter.AnimationMode.EASE_OUT_QUAD,
                duration: WIDGET_SHOWING_DURATION,
            });
        }
    }

    gestureEnd(_tracker, duration, progress) {
        switch (progress) {
            case OpenCloseWindowTabGestureState.DEFAULT:
                this._animatePreview(false, duration);
                break;
            case OpenCloseWindowTabGestureState.PINCH_IN:
                this._animatePreview(this._activePinchAnimation == PINCH_IN_ANIMATION, duration, this._invokeGestureCompleteAction.bind(this, progress));
                break;
            case OpenCloseWindowTabGestureState.PINCH_OUT:
                this._animatePreview(this._activePinchAnimation == PINCH_OUT_ANIMATION, duration, this._invokeGestureCompleteAction.bind(this, progress));
                break;
        }
    }

    _invokeGestureCompleteAction(progress) {
        switch (this._actionType) {
            case PinchGestureType.OPEN_CLOSE_WINDOW:
                if (progress == OpenCloseWindowTabGestureState.PINCH_OUT &&
                    this._activePinchAnimation == PINCH_OUT_ANIMATION) {
                    if (this._focusWindow) {
                        const windowTracker = Shell.WindowTracker.get_default();
                        const focusApp = windowTracker.get_window_app(this._focusWindow);

                        if (focusApp) {
                            focusApp.open_new_window(-1);
                        }
                    }
                }
                else if (progress == OpenCloseWindowTabGestureState.PINCH_IN &&
                    this._activePinchAnimation == PINCH_IN_ANIMATION) {
                    this._focusWindow?.delete?.(global.get_current_time());
                }

                break;

            case PinchGestureType.OPEN_CLOSE_DOCUMENT:
                if (progress == OpenCloseWindowTabGestureState.PINCH_OUT &&
                    this._activePinchAnimation == PINCH_OUT_ANIMATION) {
                    this._keyboard.sendKeys([
                        Clutter.KEY_Control_L,
                        Clutter.KEY_t,
                    ]);
                }
                else if (progress == OpenCloseWindowTabGestureState.PINCH_IN &&
                    this._activePinchAnimation == PINCH_IN_ANIMATION) {
                    this._keyboard.sendKeys([
                        Clutter.KEY_Control_L,
                        Clutter.KEY_w,
                    ]);
                }
        }
    }

    _animatePreview(gestureCompleted, duration, callback) {
        easeActor(this._preview, {
            opacity: gestureCompleted ? END_OPACITY : 255,
            scaleX: gestureCompleted
                ? this._activePinchAnimation?.end
                : this._activePinchAnimation?.start,
            scaleY: gestureCompleted
                ? this._activePinchAnimation?.end
                : this._activePinchAnimation?.start,
            duration,
            mode: Clutter.AnimationMode.EASE_OUT_QUAD,
            onStopped: () => {
                if (callback)
                    callback();
                this._gestureAnimationDone();
            },
        });
    }

    _gestureAnimationDone() {
        this._preview.hide();
        this._preview.opacity = 0;
        this._preview.set_scale(1, 1);
        this._focusWindow = undefined;
    }

}
